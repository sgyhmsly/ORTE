use simulator;
select request_stream from stream_log;
select * from stream_log;
